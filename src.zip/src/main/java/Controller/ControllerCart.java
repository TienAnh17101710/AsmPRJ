package Controller;

import dao.VariantsDAO;
import dao.VoucherDAO;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.util.*;
import model.*;

@WebServlet(name = "cartAction", urlPatterns = {"/cartAction"})
public class ControllerCart extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

           HttpSession session = request.getSession();
    List<ProdAndVar> cart = (List<ProdAndVar>) session.getAttribute("cart");
    if (cart == null) {
        cart = new ArrayList<>();
    }

    String action = request.getParameter("action");
    
    if ("applyVoucher".equals(action)) {
        String code = request.getParameter("code");
        VoucherDAO voucherDAO = new VoucherDAO();
        Voucher voucher = voucherDAO.getVoucherByCode(code);

        if (voucher != null && voucher.isValid()) {
            session.setAttribute("voucher", voucher);

            double total = 0;
            for (ProdAndVar item : cart) {
                total += item.getVariants().getPrice() * item.getQuantity();
            }

            double discount = 0;
            if (voucher.getType().equals("percent")) {
                discount = total * (voucher.getDiscount() / 100.0);
            } else {
                discount = voucher.getDiscount();
            }

            session.setAttribute("discountAmount", discount);
            session.setAttribute("error", null);
        } else {
            session.setAttribute("error", "Mã giảm giá không hợp lệ hoặc đã hết hạn!");
        }

        response.sendRedirect("cart.jsp");
        return; // Quan trọng: kết thúc xử lý tại đây
    }


        try {
            int variantId = Integer.parseInt(request.getParameter("variantId"));

            if ("remove".equals(action)) {
                cart.removeIf(item -> item.getVariants().getId() == variantId);
            } else if ("update".equals(action)) {
                int newQuantity = Integer.parseInt(request.getParameter("quantity"));

                for (ProdAndVar item : cart) {
                    if (item.getVariants().getId() == variantId) {
                        int oldQuantity = item.getQuantity();
                        int currentStock = item.getVariants().getStockQuantity();

                        int delta = newQuantity - oldQuantity;

                        if (delta > 0 && delta > currentStock) {
                            // Gửi thông báo lỗi về trang cart.jsp
                            request.setAttribute("error", "Sản phẩm còn lại không đủ.");
                            request.getRequestDispatcher("cart.jsp").forward(request, response);
                            return;
                        }

                        // Cập nhật session
                        item.setQuantity(newQuantity);

                        // Cập nhật lại trong session object
                        item.getVariants().setStockQuantity(currentStock);

                        break;
                    }
                }
            }

        } catch (NumberFormatException e) {
            e.printStackTrace(); // có thể log ra file
        }

        session.setAttribute("cart", cart);
        response.sendRedirect("cart.jsp");
    }
}
