/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package Controller;

import dao.ProductsDAO;
import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.util.ArrayList;
import java.util.List;
import model.Products;

/**
 *
 * @author anduc1234
 */
@WebServlet(name = "ControllerAdminProd", urlPatterns = {"/ControllerAdminProd"})
public class ControllerAdminProd extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet ControllerAdminProd</title>");
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet ControllerAdminProd at " + request.getContextPath() + "</h1>");
            out.println("</body>");
            out.println("</html>");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        ProductsDAO pdao = new ProductsDAO();
        List<Products> list = pdao.getAllProducts();

        if (list != null && !list.isEmpty()) {
            request.setAttribute("listProduct", list);
        } else {
            request.setAttribute("message", "Không có sản phẩm nào.");
        }

        request.getRequestDispatcher("admin/product.jsp").forward(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getParameter("action");
        String idParam = request.getParameter("id");
        ProductsDAO dao = new ProductsDAO();

        try {
            if ("edit".equals(action)) {
                if (idParam != null) {
                    int id = Integer.parseInt(idParam);
                    Products product = dao.getProductById(id);
                    if (product != null) {
                        request.setAttribute("editProduct", product);
                    } else {
                        request.setAttribute("error", "Không tìm thấy sản phẩm với ID: " + id);
                    }
                }
                List<Products> list = dao.getAllProducts();
                request.setAttribute("listProduct", list);
                request.getRequestDispatcher("admin/product.jsp").forward(request, response);

            } else if ("update".equals(action)) {
                int id = Integer.parseInt(idParam);
                String name = request.getParameter("name");
                String categoryParam = request.getParameter("categoryId");
                String img = request.getParameter("img");

                if (categoryParam != null && !categoryParam.isEmpty()) {
                    int category_id = Integer.parseInt(categoryParam);
                    Products updated = new Products();
                    updated.setId(id);
                    updated.setName(name);
                    updated.setCategoryId(category_id);
                    updated.setImg(img);

                    int result = dao.updateProduct(updated);
                    if (result == 1) {
                        response.sendRedirect("ControllerAdminProd");
                    } else {
                        request.setAttribute("error", "Cập nhật sản phẩm thất bại.");
                        request.setAttribute("listProduct", dao.getAllProducts());
                        request.getRequestDispatcher("admin/product.jsp").forward(request, response);
                    }
                } else {
                    request.setAttribute("error", "Category ID không hợp lệ.");
                    request.setAttribute("listProduct", dao.getAllProducts());
                    request.getRequestDispatcher("admin/product.jsp").forward(request, response);
                }

            } else if ("delete".equals(action)) {
                if (idParam != null) {
                    int result = dao.deleteProduct(Integer.parseInt(idParam));
                    if (result == 1) {
                        response.sendRedirect("ControllerAdminProd");
                    } else {
                        request.setAttribute("error", "Xóa sản phẩm thất bại.");
                        request.setAttribute("listProduct", dao.getAllProducts());
                        request.getRequestDispatcher("admin/product.jsp").forward(request, response);
                    }
                }

            } else if ("search".equals(action)) {
                String idSearchParam = request.getParameter("id");
                if (idSearchParam != null && !idSearchParam.isEmpty()) {
                    int idSearch = Integer.parseInt(idSearchParam);
                    Products p = dao.getProductById(idSearch);
                    if (p != null) {
                        List<Products> list = new ArrayList<>();
                        list.add(p);
                        request.setAttribute("listProduct", list);
                    } else {
                        request.setAttribute("message", "Không tìm thấy sản phẩm có ID: " + idSearch);
                    }
                } else {
                    request.setAttribute("error", "Vui lòng nhập ID để tìm.");
                }
                request.getRequestDispatcher("admin/product.jsp").forward(request, response);

            } else if ("add".equals(action)) {
                String name = request.getParameter("name");
                String categoryParam = request.getParameter("categoryId");
                String img = request.getParameter("img");

                if (categoryParam != null && !categoryParam.isEmpty()) {
                    int category_id = Integer.parseInt(categoryParam);
                    int result = dao.insertProduct(name, category_id, img);
                    if (result == 1) {
                        response.sendRedirect("ControllerAdminProd");
                    } else {
                        request.setAttribute("error", "Lỗi khi thêm sản phẩm.");
                        request.setAttribute("listProduct", dao.getAllProducts());
                        request.getRequestDispatcher("admin/product.jsp").forward(request, response);
                    }
                } else {
                    request.setAttribute("error", "Category ID không được để trống.");
                    request.setAttribute("listProduct", dao.getAllProducts());
                    request.getRequestDispatcher("admin/product.jsp").forward(request, response);
                }
            }
        } catch (NumberFormatException e) {
            request.setAttribute("error", "Lỗi định dạng số: " + e.getMessage());
            request.setAttribute("listProduct", dao.getAllProducts());
            request.getRequestDispatcher("admin/product.jsp").forward(request, response);
        }
    }



/**
 * Returns a short description of the servlet.
 *
 * @return a String containing servlet description
 */
@Override
public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
