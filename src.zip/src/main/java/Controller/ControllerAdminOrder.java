package Controller;

import dao.OrderDetailsDAO;
import dao.OrdersDAO;
import model.Orders;
import java.io.IOException;
import java.util.*;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import model.OrderDetails;
import model.Variants;
import dao.VariantsDAO;
import model.Products;
import dao.ProductsDAO;
import dao.CustomersDAO;
import model.Customers;
import model.Staff;
import dao.StaffDAO;

@WebServlet(name = "ControllerAdminOrders", urlPatterns = {"/ControllerAdminOrders"})
public class ControllerAdminOrder extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        OrdersDAO dao = new OrdersDAO();
        List<Orders> list = dao.getAllOrders();

        OrderDetailsDAO odao = new OrderDetailsDAO();
        List<OrderDetails> dlist = odao.getAllOrderDetails();

        VariantsDAO vdao = new VariantsDAO();
        List<Variants> vlist = new ArrayList<>();
        for (OrderDetails l : dlist) {
            int vid = l.getVariantId();
            Variants v = vdao.getVariantByID(vid);
            vlist.add(v);
        }

        ProductsDAO pdao = new ProductsDAO();
        List<Products> plist = new ArrayList<>();
        for (Variants v : vlist) {
            int vid = v.getProductId();
            Products p = pdao.getProductById(vid);
            plist.add(p);
        }

        if (list != null) {
            request.setAttribute("varilist", vlist);
            request.setAttribute("listPname", plist);
            request.setAttribute("listOrders", list);
            request.setAttribute("listOrderDetails", dlist);
            request.getRequestDispatcher("admin/orders.jsp").forward(request, response);
        } else {
            response.getWriter().write("Không có dữ liệu đơn hàng.");
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String idParam = request.getParameter("id");
        String action = request.getParameter("action");

        OrdersDAO dao = new OrdersDAO();

        if ("search".equals(action)) {
            try {
                int idSearch = Integer.parseInt(idParam);
                Orders order = dao.getOrdersById(idSearch);
                OrderDetailsDAO odao = new OrderDetailsDAO();
                List<OrderDetails> dlist = odao.getAllOrderDetails();

                VariantsDAO vdao = new VariantsDAO();
                List<Variants> vlist = new ArrayList<>();
                for (OrderDetails l : dlist) {
                    int vid = l.getVariantId();
                    Variants v = vdao.getVariantByID(vid);
                    vlist.add(v);
                }

                ProductsDAO pdao = new ProductsDAO();
                List<Products> plist = new ArrayList<>();
                for (Variants v : vlist) {
                    int vid = v.getProductId();
                    Products p = pdao.getProductById(vid);
                    plist.add(p);
                }

                if (order != null) {
                    List<Orders> list = new ArrayList<>();
                    list.add(order);
                    request.setAttribute("listOrders", list);
                    request.setAttribute("varilist", vlist);
                    request.setAttribute("listPname", plist);
                    request.setAttribute("listOrderDetails", dlist);
                } else {
                    request.setAttribute("message", "Không tìm thấy đơn hàng có ID: " + idSearch);
                }
            } catch (NumberFormatException e) {
                request.setAttribute("message", "ID không hợp lệ.");
            }
            request.getRequestDispatcher("admin/orders.jsp").forward(request, response);

        } else if ("delete".equals(action)) {
            try {
                int id = Integer.parseInt(idParam);
                Orders o=dao.getOrdersById(id);
                
                int staff_id=o.getStaffId();
                StaffDAO sdao=new StaffDAO();
                sdao.setStaffStatus(staff_id);
                
                int result = dao.deleteOrders(id);
                
                if (result == 1) {
                    response.sendRedirect("ControllerAdminOrders");
                } else {
                    request.setAttribute("message", "Không thể xóa đơn hàng.");
                    List<Orders> list = dao.getAllOrders();
                    request.setAttribute("listOrders", list);
                    request.getRequestDispatcher("admin/orders.jsp").forward(request, response);
                }
            } catch (NumberFormatException e) {
                request.setAttribute("message", "ID không hợp lệ.");
                List<Orders> list = dao.getAllOrders();
                request.setAttribute("listOrders", list);
                request.getRequestDispatcher("admin/orders.jsp").forward(request, response);
            }
        } else if ("done".equals(action)) {
            String id = request.getParameter("id");

            int result = dao.setStatus(Integer.parseInt(id));

            Orders order = dao.getOrdersById(Integer.parseInt(id));
            int staffId = order.getStaffId();
            StaffDAO sdao = new StaffDAO();
            sdao.setStaffStatus(staffId);
            List<Orders> list = dao.getAllOrders();
            response.sendRedirect("ControllerAdminOrders");
        } else if ("bill".equals(action)) {
            String id = request.getParameter("id");

            Orders o = dao.getOrdersById(Integer.parseInt(id));

            int iduser = o.getUserId();

            CustomersDAO cdao = new CustomersDAO();
            Customers c = cdao.getCustomerByid(iduser);

            List<Orders> list = dao.getAllOrders();

            OrderDetailsDAO odao = new OrderDetailsDAO();
            List<OrderDetails> dlist = odao.getOrderdetailById(o.getId());

            VariantsDAO vdao = new VariantsDAO();
            List<Variants> vlist = new ArrayList<>();
            for (OrderDetails l : dlist) {
                int vid = l.getVariantId();
                Variants v = vdao.getVariantByID(vid);
                vlist.add(v);
            }

            ProductsDAO pdao = new ProductsDAO();
            List<Products> plist = new ArrayList<>();
            for (Variants v : vlist) {
                int vid = v.getProductId();
                Products p = pdao.getProductById(vid);
                plist.add(p);
            }
            StaffDAO sdao = new StaffDAO();
            Staff s = sdao.getStaffById(o.getStaffId());
            if (list != null) {
                request.setAttribute("customer", c);
                request.setAttribute("varilist", vlist);
                request.setAttribute("listPname", plist);
                request.setAttribute("order", o);
                request.setAttribute("staff", s);
                request.setAttribute("listOrderDetails", dlist);
                request.getRequestDispatcher("bill.jsp").forward(request, response);
            } else {
                response.getWriter().write("Không có dữ liệu đơn hàng.");
            }

        }
    }

    @Override
    public String getServletInfo() {
        return "Controller dùng để xem và xoá đơn hàng";
    }
}
