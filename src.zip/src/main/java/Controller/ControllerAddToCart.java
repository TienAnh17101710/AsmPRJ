package Controller;

import dao.ProductsDAO;
import dao.VariantsDAO;
import model.*;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.util.*;

@WebServlet(name = "addToCart", urlPatterns = {"/addToCart"})
public class ControllerAddToCart extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        int productId = Integer.parseInt(request.getParameter("productId"));
        String size = request.getParameter("size");
        String sugar = request.getParameter("sugar");
        String ice = request.getParameter("ice");

        ProductsDAO pdao = new ProductsDAO();
        VariantsDAO vdao = new VariantsDAO();

        Products product = pdao.getProductById(productId);
        Variants variant = vdao.getVariantByOptions(productId, size, sugar, ice);

        if (variant == null) {
            response.sendRedirect("Cp");
            return;
        }

        // Tạo session
        HttpSession session = request.getSession();
        List<ProdAndVar> cart = (List<ProdAndVar>) session.getAttribute("cart");

        if (cart == null) {
            cart = new ArrayList<>();
        }

        // Kiểm tra đã tồn tại chưa
        boolean found = false;
        for (ProdAndVar item : cart) {
            if (item.getVariants().getId() == variant.getId()) {
                item.setQuantity(item.getQuantity() + 1);
                found = true;
                break;
            }
        }

        if (!found) {
            cart.add(new ProdAndVar(product, variant, 1));
        }

        session.setAttribute("cart", cart);
        response.sendRedirect("Cp");
    }
}
