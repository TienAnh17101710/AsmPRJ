/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package Controller;

import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.util.*;
import dao.StaffDAO;
import model.Staff;

/**
 *
 * @author Acer - PC
 */
@WebServlet(name = "ControllerAdminStaff", urlPatterns = {"/ControllerAdminStaff"})
public class ControllerAdminStaff extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet ControllerStaff</title>");
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet ControllerStaff at " + request.getContextPath() + "</h1>");
            out.println("</body>");
            out.println("</html>");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        //processRequest(request, response);
        StaffDAO sdao = new StaffDAO();
        List<Staff> list = sdao.getAllStaff();

        if (list != null) {
            request.setAttribute("listStaff", list);
            request.getRequestDispatcher("admin/staff.jsp").forward(request, response);
        } else {
            response.getWriter().write("Không có dữ liệu nhân viên.");
        }
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String id = request.getParameter("id");
        String action = request.getParameter("action");

        StaffDAO dao = new StaffDAO();

        if ("edit".equals(action)) {
            int idparam = Integer.parseInt(request.getParameter("id"));
            Staff staff = dao.getStaffById(idparam); 
            if (staff != null) {
                request.setAttribute("editStaff", staff);
            } else {
                request.setAttribute("error", "Không tìm thấy nhân viên với ID " + id);
            }
            List<Staff> list = dao.getAllStaff();
            request.setAttribute("listStaff", list);
            request.getRequestDispatcher("admin/staff.jsp").forward(request, response);
        } else if ("update".equals(action)) {
            int idupdate = Integer.parseInt(request.getParameter("id"));
            String name = request.getParameter("name");
            String phone = request.getParameter("phone");
            String email = request.getParameter("email");
            String username = request.getParameter("username");
            String password = request.getParameter("password");
            String status = request.getParameter("status");
            int result = dao.updateStaff(new Staff(idupdate, name, phone, email, username, password, status));
            if (result == 1) {
                response.sendRedirect("ControllerAdminStaff");
            } else {
                request.setAttribute("error", "Cập nhật thất bại.");
                List<Staff> list = dao.getAllStaff();
                request.setAttribute("listStaff", list);
                request.getRequestDispatcher("admin/staff.jsp").forward(request, response);
            }
        } else if ("delete".equals(action)) {
            int result = dao.deleteStaff(Integer.parseInt(id));
            if (result == 1) {
                response.sendRedirect("ControllerAdminStaff");
            }

        } else if ("search".equals(action)) {
            int idSearch = Integer.parseInt(request.getParameter("id"));
            Staff s = dao.getStaffById(idSearch);
            if (s != null) {
                List<Staff> list = new ArrayList<>();
                list.add(s);
                request.setAttribute("listStaff", list);
            } else {
                request.setAttribute("message", "Không tìm thấy nhân viên có ID: " + idSearch);
            }
            request.getRequestDispatcher("admin/staff.jsp").forward(request, response);
        } else if ("add".equals(action)) {
            String name = request.getParameter("name");
            String phone = request.getParameter("phone");
            String email = request.getParameter("email");
            String username = request.getParameter("username");
            String password = request.getParameter("password");
            String status = request.getParameter("status");
            if (status == null || status.isEmpty()) {
                status = "active"; // hoặc "đang làm"
            }

            // Kiểm tra username đã tồn tại chưa
            if (dao.isUsernameExist(username)) {
                request.setAttribute("error", "Tên đăng nhập đã tồn tại. Vui lòng chọn tên khác.");
                List<Staff> list = dao.getAllStaff();
                request.setAttribute("listStaff", list);
                request.getRequestDispatcher("admin/staff.jsp").forward(request, response);
            } else {
                int result = dao.insertStaff(name, phone, email, username, password, status);
                if (result == 1) {
                    response.sendRedirect("ControllerAdminStaff"); // reload lại trang danh sách
                } else {
                    request.setAttribute("error", "Lỗi khi thêm nhân viên.");
                    List<Staff> list = dao.getAllStaff();
                    request.setAttribute("listStaff", list);
                    request.getRequestDispatcher("admin/staff.jsp").forward(request, response);
                }
            }
        }

    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
