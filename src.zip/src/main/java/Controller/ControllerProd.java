package Controller;

import dao.*;
import model.*;
import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.util.*;

@WebServlet(name = "Cp", urlPatterns = {"/Cp"})
public class ControllerProd extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet ControllerProd</title>");
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet ControllerProd at " + request.getContextPath() + "</h1>");
            out.println("</body>");
            out.println("</html>");
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        ProductsDAO pro = new ProductsDAO();
        List<Products> p = pro.getAllProducts();

        VariantsDAO var = new VariantsDAO();
        List<Variants> v = var.getAllVariants();

        Set<String> allIMG = new HashSet<>();
        Set<String> allName = new HashSet<>();
        Set<String> allSizes = new HashSet<>();
        Set<String> allSugars = new HashSet<>();
        Set<String> allIces = new HashSet<>();
        CategoriesDAO cdao = new CategoriesDAO();
        List<Categories> listCa = cdao.getAllCategories();
        
        //lấy list yêu thích của khách
        HttpSession session = request.getSession(); 
        Customers cus= (Customers) session.getAttribute("customer");
        if(cus!=null){
            int cusId=cus.getCustomer_id();
            FavoriteDAO fdao=new FavoriteDAO();
            List<Products> list=fdao.getFavoriteProducts(cusId);
            request.setAttribute("listFa", list);
        }

// Tạo danh sách ID của các category có status == 0
        Set<Integer> inactiveCategoryIds = new HashSet<>();
        Iterator<Categories> catIterator = listCa.iterator();
        while (catIterator.hasNext()) {
            Categories c = catIterator.next();
            if (c.getStatus() == 0) {
                inactiveCategoryIds.add(c.getCategory_id());
                catIterator.remove(); //xóa khỏi danh sách hiển thị 
            }
        }

// Xóa sản phẩm có categoryId nằm trong danh sách status == 0
        Iterator<Products> proIterator = p.iterator();
        while (proIterator.hasNext()) {
            Products prod = proIterator.next();
            if (inactiveCategoryIds.contains(prod.getCategoryId())) {
                proIterator.remove();
            }
        }

        for (Products prod : p) {
            allIMG.add(prod.getName());
            allName.add(prod.getImg());
        }
        for (Variants vari : v) {
            allSizes.add(vari.getSize());
            allSugars.add(vari.getSugar());
            allIces.add(vari.getIce());
        }

        request.setAttribute("listCategory", listCa);

        request.setAttribute("sizes", allSizes);
        request.setAttribute("sugars", allSugars);
        request.setAttribute("ices", allIces);
        request.setAttribute("img", allIMG);
        request.setAttribute("name", allName);
        request.setAttribute("product", p);
        request.setAttribute("variant", v);
        request.getRequestDispatcher("prod.jsp").forward(request, response);
    }
}
