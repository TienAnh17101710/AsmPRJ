package Controller;

import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import dao.CategoriesDAO;
import java.util.*;
import dao.CategoriesDAO;
import model.Categories;

@WebServlet(name = "ControllerAdminCategories", urlPatterns = {"/ControllerAdminCategories"})
public class ControllerAdminCategories extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        CategoriesDAO dao = new CategoriesDAO();
        List<Categories> list = dao.getAllCategories();

        if (list != null) {
            request.setAttribute("listCategories", list);
            request.getRequestDispatcher("admin/categories.jsp").forward(request, response);
        } else {
            response.getWriter().write("Không có dữ liệu danh mục.");
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getParameter("action");
        String id = request.getParameter("id");

        CategoriesDAO dao = new CategoriesDAO();

        if ("edit".equals(action)) {
            int idparam = Integer.parseInt(request.getParameter("id"));
            Categories category = dao.getCategoriesByID(idparam);
            if (category != null) {
                request.setAttribute("editCategory", category);
            } else {
                request.setAttribute("error", "Không tìm thấy danh mục với ID " + id);
            }
            List<Categories> list = dao.getAllCategories();
            request.setAttribute("listCategories", list);
            request.getRequestDispatcher("admin/categories.jsp").forward(request, response);

        } else if ("update".equals(action)) {
            int idUpdated = Integer.parseInt(id);
            String name = request.getParameter("name");
            String description = request.getParameter("description");
            Categories updated = new Categories();
            updated.setId(idUpdated);
            updated.setDescription(description);
            updated.setName(name);
            int result = dao.updateCategories(updated);
            if (result == 1) {
                response.sendRedirect("ControllerAdminCategories");
            } else {
                request.setAttribute("error", "Cập nhật thất bại.");
                List<Categories> list = dao.getAllCategories();
                request.setAttribute("listCategories", list);
                request.getRequestDispatcher("admin/categories.jsp").forward(request, response);
            }

        } else if ("delete".equals(action)) {
            int result = dao.deleteCategories(Integer.parseInt(id));
            if (result == 1) {
                response.sendRedirect("ControllerAdminCategories");
            }

        } else if ("search".equals(action)) {
            int idSearch = Integer.parseInt(request.getParameter("id"));
            Categories c = dao.getCategoriesByID(idSearch);
            if (c != null) {
                List<Categories> list = new ArrayList<>();
                list.add(c);
                request.setAttribute("listCategories", list);
            } else {
                request.setAttribute("message", "Không tìm thấy danh mục có ID: " + idSearch);
            }
            request.getRequestDispatcher("admin/categories.jsp").forward(request, response);

        } else if ("add".equals(action)) {
            String name = request.getParameter("name");
            String description = request.getParameter("description");

            if (dao.isCategoryNameExist(name)) {
                request.setAttribute("error", "Tên danh mục đã tồn tại.");
                List<Categories> list = dao.getAllCategories();
                request.setAttribute("listCategories", list);
                request.getRequestDispatcher("admin/categories.jsp").forward(request, response);
            } else {
                int result = dao.insertCategories(name, description);
                if (result == 1) {
                    response.sendRedirect("ControllerAdminCategories");
                } else {
                    request.setAttribute("error", "Lỗi khi thêm danh mục.");
                    List<Categories> list = dao.getAllCategories();
                    request.setAttribute("listCategories", list);
                    request.getRequestDispatcher("admin/categories.jsp").forward(request, response);
                }
            }
        } else if ("toggleStatus".equals(action)) {
            int cid = Integer.parseInt(request.getParameter("id"));
            int result = dao.toggleCategoryStatusIfNoActiveOrders(cid);
            if (result == 0) {
                request.setAttribute("errorstop", "Không thể ngừng danh mục vì đang có đơn hàng chưa hoàn thành.");

            }
            List<Categories> list = dao.getAllCategories();
            request.setAttribute("listCategories", list);
            request.getRequestDispatcher("admin/categories.jsp").forward(request, response);
        } else if ("filter".equals(action)) {
            int status = Integer.parseInt(request.getParameter("status"));
            List<Categories> list;
            if (status == -1) {
                list = dao.getAllCategories();
            } else {
                list = new ArrayList<>();
                List<Categories> listall=dao.getAllCategories();
                for(Categories c:listall){
                    int s=c.getStatus();
                    if(s==status){
                        list.add(c);
                    }
                }
            }
            request.setAttribute("listCategories", list);
            request.getRequestDispatcher("admin/categories.jsp").forward(request, response);
        }

    }

    @Override
    public String getServletInfo() {
        return "Quản lý danh mục sản phẩm";
    }
}
