/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package Controller;

import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.util.*;
import model.Voucher;
import dao.VoucherDAO;
import java.text.SimpleDateFormat;
/**
 *
 * @author Acer - PC
 */
@WebServlet(name = "ControllerAdminVoucher", urlPatterns = {"/ControllerAdminVoucher"})
public class ControllerAdminVoucher extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet ControllerAdminVoucher</title>");
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet ControllerAdminVoucher at " + request.getContextPath() + "</h1>");
            out.println("</body>");
            out.println("</html>");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    VoucherDAO dao = new VoucherDAO();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // processRequest(request, response);

        String action = request.getParameter("action");

        if ("delete".equals(action)) {
            String code = request.getParameter("code");
            dao.deleteVoucher(code);
        }

        // Sau khi thao tác xong, luôn load lại danh sách
        List<Voucher> list = dao.getAllVouchers();
        request.setAttribute("voucherList", list);
        request.getRequestDispatcher("admin/voucher.jsp").forward(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        request.setCharacterEncoding("UTF-8");

        String action = request.getParameter("action");
        String code = request.getParameter("code");
        String type = request.getParameter("type");
        String discountStr = request.getParameter("discount");
        String expiryStr = request.getParameter("expiryDate");
        String statusStr = request.getParameter("status");

        try {
            double discount = Double.parseDouble(discountStr);
            int status = Integer.parseInt(statusStr);

            // Chuyển String -> java.sql.Date
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
            Date utilDate = sdf.parse(expiryStr);
            java.sql.Date expiryDate = new java.sql.Date(utilDate.getTime());

            Voucher v = new Voucher();
            v.setCode(code);
            v.setType(type);
            v.setDiscount(discount);
            v.setExpiredDate(expiryDate);
            v.setStatus(status);

            if ("create".equals(action)) {
                dao.insertVoucher(v);
            } else if ("update".equals(action)) {
                dao.updateVoucher(v);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        // Quay lại trang chính sau thao tác
        List<Voucher> list = dao.getAllVouchers();
        request.setAttribute("voucherList", list);
        request.getRequestDispatcher("admin/voucher.jsp").forward(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
