/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package Controller;

import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import dao.*;
import jakarta.servlet.http.HttpSession;
import java.util.*;
import model.*;

/**
 *
 * @author Duong Quy Nhan
 */
@WebServlet(name = "searchController", urlPatterns = {"/search"})
public class searchController extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet searchController</title>");
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet searchController at " + request.getContextPath() + "</h1>");
            out.println("</body>");
            out.println("</html>");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String keyword = request.getParameter("query");

        ProductsDAO pro = new ProductsDAO();
        List<Products> p = pro.searchProductsByName(keyword);

        VariantsDAO var = new VariantsDAO();
        List<Variants> v = var.getAllVariants();

        Set<String> allIMG = new HashSet<>();
        Set<String> allName = new HashSet<>();
        Set<String> allSizes = new HashSet<>();
        Set<String> allSugars = new HashSet<>();
        Set<String> allIces = new HashSet<>();

        CategoriesDAO cdao = new CategoriesDAO();
        List<Categories> listCa = cdao.getAllCategories();
        Iterator<Categories> iterator = listCa.iterator();
        while (iterator.hasNext()) {
            Categories c = iterator.next();
            if (c.getStatus() == 0) {
                iterator.remove();
            }
        }

        for (Products prod : p) {
            allIMG.add(prod.getName());
            allName.add(prod.getImg());
        }
        for (Variants vari : v) {
            allSizes.add(vari.getSize());
            allSugars.add(vari.getSugar());
            allIces.add(vari.getIce());
        }

        //lấy list yêu thích của khách
        HttpSession session = request.getSession();
        Customers cus = (Customers) session.getAttribute("customer");
        if (cus != null) {
            int cusId = cus.getCustomer_id();
            FavoriteDAO fdao = new FavoriteDAO();
            List<Products> list = fdao.getFavoriteProducts(cusId);
            request.setAttribute("listFa", list);
        }

        request.setAttribute("listCategory", listCa);
        request.setAttribute("sizes", allSizes);
        request.setAttribute("sugars", allSugars);
        request.setAttribute("ices", allIces);
        request.setAttribute("img", allIMG);
        request.setAttribute("name", allName);
        request.setAttribute("product", p);
        request.setAttribute("variant", v);

        request.getRequestDispatcher("prod.jsp").forward(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String keyword = request.getParameter("query");
        String selectedCategory = request.getParameter("category");
        ProductsDAO pro = new ProductsDAO();
        List<Products> p = pro.searchProductsByName(keyword);
        VariantsDAO var = new VariantsDAO();
        List<Variants> v = var.getAllVariants();

        Set<String> allIMG = new HashSet<>();
        Set<String> allName = new HashSet<>();
        Set<String> allSizes = new HashSet<>();
        Set<String> allSugars = new HashSet<>();
        Set<String> allIces = new HashSet<>();

        CategoriesDAO cdao = new CategoriesDAO();
        List<Categories> listCa = cdao.getAllCategories();
        Iterator<Categories> iterator = listCa.iterator();
        while (iterator.hasNext()) {
            Categories c = iterator.next();
            if (c.getStatus() == 0) {
                iterator.remove();
            }
        }
        // Nếu có chọn category cụ thể, lọc tiếp
        if (selectedCategory != null) {
            if (selectedCategory.equals("all")) {
                response.sendRedirect("Cp");
                return;
            }
            if ("love".equals(selectedCategory)) {
                HttpSession session = request.getSession();
                Customers cus = (Customers) session.getAttribute("customer");
                if (cus != null) {
                    int cusId = cus.getCustomer_id();
                    FavoriteDAO fdao = new FavoriteDAO();
                    List<Products> favList = fdao.getFavoriteProducts(cusId);
                    p = favList;
                } else {
                    p = new ArrayList<>();
                }
            } else {
                try {
                    int selectedCategoryId = Integer.parseInt(selectedCategory);
                    p.removeIf(prod -> prod.getCategoryId() != selectedCategoryId);
                } catch (NumberFormatException e) {
                    // không cần xử lý, giữ nguyên danh sách
                }
            }
        }

        for (Products prod : p) {
            allIMG.add(prod.getName());
            allName.add(prod.getImg());
        }
        for (Variants vari : v) {
            allSizes.add(vari.getSize());
            allSugars.add(vari.getSugar());
            allIces.add(vari.getIce());
        }
        //lấy list yêu thích của khách
        HttpSession session = request.getSession();
        Customers cus = (Customers) session.getAttribute("customer");
        if (cus != null) {
            int cusId = cus.getCustomer_id();
            FavoriteDAO fdao = new FavoriteDAO();
            List<Products> list = fdao.getFavoriteProducts(cusId);
            request.setAttribute("listFa", list);
        }

        request.setAttribute("listCategory", listCa);
        request.setAttribute("sizes", allSizes);
        request.setAttribute("sugars", allSugars);
        request.setAttribute("ices", allIces);
        request.setAttribute("img", allIMG);
        request.setAttribute("name", allName);
        request.setAttribute("product", p);
        request.setAttribute("variant", v);

        request.getRequestDispatcher("prod.jsp").forward(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
