/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package Controller;

import dao.*;
import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.util.*;
import model.*;
import dao.*;
import jakarta.mail.MessagingException;

/**
 *
 * @author Duong Quy Nhan
 */
@WebServlet(name = "CheckoutController", urlPatterns = {"/CheckoutController"})
public class CheckoutController extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        try {
            HttpSession session = request.getSession();
            List<ProdAndVar> cart = (List<ProdAndVar>) session.getAttribute("cart");

            if (cart == null || cart.isEmpty()) {
                request.setAttribute("error", "Giỏ hàng đang trống. Vui lòng thêm sản phẩm vào giỏ.");
                request.getRequestDispatcher("cart.jsp").forward(request, response);
                return;
            }

            Customers customer = (Customers) session.getAttribute("customer");
            if (customer == null) {
                request.setAttribute("error", "Bạn cần đăng nhập để đặt hàng.");
                request.getRequestDispatcher("login.jsp").forward(request, response);
                return;
            }

            int customerId = customer.getCustomer_id();
            long totalAmount = 0;
            for (ProdAndVar item : cart) {
                totalAmount += (long) (item.getVariants().getPrice() * item.getQuantity());
            }
            // Kiểm tra và áp dụng voucher nếu có
            Voucher voucher = (Voucher) session.getAttribute("voucher");
            if (voucher != null && voucher.isValid()) {
                double discount = 0;
                if ("percent".equalsIgnoreCase(voucher.getType())) {
                    discount = totalAmount * (voucher.getDiscount() / 100.0);
                } else {
                    discount = voucher.getDiscount();
                }

                totalAmount -= (long) discount;
                if (totalAmount < 0) {
                    totalAmount = 0; // Tránh âm
                }
            }
            StaffDAO sdao = new StaffDAO();
            int staffId = sdao.getIdStaffReaddy();
            if (staffId <= 0) {
                request.setAttribute("error", "Không có nhân viên nào sẵn sàng xử lý đơn hàng.");
                request.getRequestDispatcher("cart.jsp").forward(request, response);
                return;
            }

            Orders order = new Orders(
                    customerId,
                    staffId,
                    new java.sql.Date(System.currentTimeMillis()),
                    totalAmount,
                    "0"
            );

            OrdersDAO ordersDAO = new OrdersDAO();
            int orderId = ordersDAO.insertOrder(order);
            if (orderId <= 0) {
                request.setAttribute("error", "Không thể tạo đơn hàng. Vui lòng thử lại.");
                request.getRequestDispatcher("cart.jsp").forward(request, response);
                return;
            }

            OrderDetailsDAO detailsDAO = new OrderDetailsDAO();
            VariantsDAO variantsDAO = new VariantsDAO();
            for (ProdAndVar item : cart) {
                int result = detailsDAO.insertOrderDetail(
                        new OrderDetails(0, orderId, item.getVariants().getId(), item.getQuantity())
                );
                if (result <= 0) {
                    request.setAttribute("error", "Không thể lưu chi tiết đơn hàng.");
                    request.getRequestDispatcher("cart.jsp").forward(request, response);
                    return;
                }
                //  Cập nhật số lượng tồn kho
                int currentStock = item.getVariants().getStockQuantity();
                int orderedQty = item.getQuantity();
                int updatedStock = currentStock - orderedQty;
                variantsDAO.updateStockQuantity(item.getVariants().getId(), updatedStock);
            }
            String customerEmail = customer.getEmail();
            String subject = "Order successfully at Coffee Shop!";
            String content = "Cảm ơn bạn đã đặt hàng. Đơn hàng của bạn đang được sử lý";
            
            // gửi mail
            try {
                EmailUtils.sendEmail(customerEmail, subject, content);
            } catch (MessagingException e) {
                e.printStackTrace(); 
            }
            // Đánh dấu nhân viên đang xử lý
            sdao.setStaffStatus(staffId);

            // Xoá giỏ hàng
            session.removeAttribute("cart");

            session.removeAttribute("voucher");
            session.removeAttribute("discountAmount");

            // Thành công
            response.sendRedirect("Cp");

        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("error", "Đã xảy ra lỗi: " + e.getMessage());
            request.getRequestDispatcher("cart.jsp").forward(request, response);
        }
    }

}
