/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package Controller;

import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import model.*;
import dao.*;
import java.util.*;

/**
 *
 * @author Acer - PC
 */
@WebServlet(name = "ControllerProfile", urlPatterns = {"/ControllerProfile"})
public class ControllerProfile extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet ControllerProfile</title>");
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet ControllerProfile at " + request.getContextPath() + "</h1>");
            out.println("</body>");
            out.println("</html>");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // Lấy thông tin đăng nhập từ session
        HttpSession session = request.getSession();
        Customers customerSession = (Customers) session.getAttribute("customer");

        // Truy vấn lại thông tin từ database theo ID 
        CustomersDAO dao = new CustomersDAO();
        Customers customer = dao.getCustomerByid(customerSession.getCustomer_id());
        //truy vấn lấy toàn bộ order của khách hàng
        List<Orders> list = new ArrayList<>();
        if (request.getParameter("showOrder") != null) {
            OrdersDAO ordersDAO = new OrdersDAO();
            list = ordersDAO.getOrdersByCustomerId(customerSession.getCustomer_id());
            request.setAttribute("orders", list);
        }

        if (customer != null) {
            request.setAttribute("customer", customer);
            request.getRequestDispatcher("profile.jsp").forward(request, response);
        } else {
            response.getWriter().write("Không tìm thấy khách hàng.");
        }

    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        //processRequest(request, response);
        OrdersDAO dao = new OrdersDAO();
        String id = request.getParameter("id");

        Orders o = dao.getOrdersById(Integer.parseInt(id));

        int iduser = o.getUserId();

        CustomersDAO cdao = new CustomersDAO();
        Customers c = cdao.getCustomerByid(iduser);

        List<Orders> list = dao.getAllOrders();

        OrderDetailsDAO odao = new OrderDetailsDAO();
        List<OrderDetails> dlist = odao.getOrderdetailById(o.getId());

        VariantsDAO vdao = new VariantsDAO();
        List<Variants> vlist = new ArrayList<>();
        for (OrderDetails l : dlist) {
            int vid = l.getVariantId();
            Variants v = vdao.getVariantByID(vid);
            vlist.add(v);
        }

        ProductsDAO pdao = new ProductsDAO();
        List<Products> plist = new ArrayList<>();
        for (Variants v : vlist) {
            int vid = v.getProductId();
            Products p = pdao.getProductById(vid);
            plist.add(p);
        }
        StaffDAO sdao = new StaffDAO();
        Staff s = sdao.getStaffById(o.getStaffId());
        if (list != null) {
            request.setAttribute("customer", c);
            request.setAttribute("varilist", vlist);
            request.setAttribute("listPname", plist);
            request.setAttribute("order", o);
            request.setAttribute("staff", s);
            request.setAttribute("listOrderDetails", dlist);
            request.getRequestDispatcher("bill.jsp").forward(request, response);
        } else {
            response.getWriter().write("Không có dữ liệu đơn hàng.");
        }
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
