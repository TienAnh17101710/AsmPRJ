package dao;

import java.sql.*;
import java.util.*;
import model.*;

public class OrderDetailsDAO extends DBconnection {

    public List<OrderDetails> getAllOrderDetails() {
        List<OrderDetails> list = new ArrayList<>();
        String sql = "SELECT * FROM Order_Details";
        try {
            connectDB();
            PreparedStatement ps = conn.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new OrderDetails(
                        rs.getInt("id"),
                        rs.getInt("order_id"),
                        rs.getInt("variant_id"),
                        rs.getInt("quantity")
                ));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    public int insertOrderDetail(OrderDetails detail) {
        String sql = "INSERT INTO Order_Details (order_id, variant_id, quantity) VALUES (?, ?, ?)";
        try {
            connectDB();
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, detail.getOrderId());
            ps.setInt(2, detail.getVariantId());
            ps.setInt(3, detail.getQuantity());
            int rowsUpdated = ps.executeUpdate();  
            return rowsUpdated;

        } catch (Exception e) {
            e.printStackTrace();
        }
        return -1;
    }

    public void deleteOrderDetailsByOrderId(int orderId) {
        String sql = "DELETE FROM Order_Details WHERE order_id = ?";
        connectDB();

        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, orderId);
            ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public List<OrderDetails> getOrderdetailById(int id) {
        List<OrderDetails> list = new ArrayList<>();
        String query = "select * from Order_Details where order_id=?";
        connectDB();

        try (PreparedStatement ps = conn.prepareStatement(query)) {
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new OrderDetails(
                        rs.getInt("id"),
                        rs.getInt("order_id"),
                        rs.getInt("variant_id"),
                        rs.getInt("quantity")
                ));
            }
            return list;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }
}
