/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import model.Voucher;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.*;

/**
 *
 * @author Acer - PC
 */
public class VoucherDAO extends DBconnection {

    public Voucher getVoucherByCode(String code) {
        connectDB();
        String query = "SELECT * FROM Voucher WHERE code = ? AND status = 1 AND expired_date >= GETDATE()";
        try (PreparedStatement ps = conn.prepareStatement(query)) {
            ps.setString(1, code);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                Voucher v = new Voucher();
                v.setId(rs.getInt("id"));
                v.setCode(rs.getString("code"));
                v.setDiscount(rs.getDouble("discount"));
                v.setType(rs.getString("type"));
                v.setMinOrder(rs.getDouble("min_order"));
                v.setExpiredDate(rs.getDate("expired_date"));
                v.setStatus(rs.getInt("status"));
                return v;
            }
        } catch (Exception e) {
            System.out.println("Get voucher error: " + e.getMessage());
        }
        return null;
    }

    public boolean insertVoucher(Voucher v) {
        String sql = "INSERT INTO Voucher (code, type, discount, expired_date, status) VALUES (?, ?, ?, ?, ?)";
        connectDB();
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, v.getCode());
            ps.setString(2, v.getType());
            ps.setDouble(3, v.getDiscount());
            ps.setDate(4, new java.sql.Date(v.getExpiredDate().getTime()));
            ps.setInt(5, v.getStatus());

            int rows = ps.executeUpdate();
            return rows > 0;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    public List<Voucher> getAllVouchers() {
        List<Voucher> list = new ArrayList<>();
        connectDB();
        String query = "SELECT * FROM Voucher";
        try (PreparedStatement ps = conn.prepareStatement(query); ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                Voucher v = new Voucher();
                v.setId(rs.getInt("id"));
                v.setCode(rs.getString("code"));
                v.setDiscount(rs.getDouble("discount"));
                v.setType(rs.getString("type"));
                v.setMinOrder(rs.getDouble("min_order"));
                v.setExpiredDate(rs.getDate("expired_date"));
                v.setStatus(rs.getInt("status"));
                list.add(v);
            }

        } catch (Exception e) {
            System.out.println("getAllVouchers error: " + e.getMessage());
        }
        return list;
    }

    public void updateVoucher(Voucher v) {
        connectDB();
        String sql = "UPDATE Voucher SET type = ?, discount = ?, min_order = ?, expired_date = ?, status = ? WHERE code = ?";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, v.getType());
            ps.setDouble(2, v.getDiscount());
            ps.setDouble(3, v.getMinOrder());
            ps.setDate(4, new java.sql.Date(v.getExpiredDate().getTime()));
            ps.setInt(5, v.getStatus());
            ps.setString(6, v.getCode());
            ps.executeUpdate();
        } catch (Exception e) {
            System.out.println("updateVoucher error: " + e.getMessage());
        }
    }
    String sql = "UPDATE Voucher SET status = 0 WHERE code = ?";

    public void deleteVoucher(String code) {
        connectDB();
        String sql = "DELETE FROM Voucher WHERE code = ?";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, code);
            ps.executeUpdate();
        } catch (Exception e) {
            System.out.println("deleteVoucher error: " + e.getMessage());
        }
    }

}
