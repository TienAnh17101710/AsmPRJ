package dao;

import java.sql.*;
import java.util.*;

public class StatisticsDAO extends DBconnection {

    // 1. Thống kê số lượng đơn theo trạng thái
    public Map<String, Integer> getOrderCountByStatus() {
        Map<String, Integer> data = new LinkedHashMap<>();
        String sql = "SELECT status, COUNT(*) AS count FROM Orders GROUP BY status";
        try {
            connectDB();
            PreparedStatement ps = conn.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                int status = rs.getInt("status");
                String label = (status == 0) ? "Chưa hoàn thành" : "Hoàn thành";
                data.put(label, rs.getInt("count"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return data;
    }

    // 2. Tổng tồn kho theo danh mục
    public Map<String, Integer> getStockByCategory() {
        Map<String, Integer> data = new LinkedHashMap<>();
        String sql = "SELECT c.name AS category, SUM(v.stock_quantity) AS total_stock "
                + "FROM Categories c "
                + "JOIN Products p ON c.id = p.category_id "
                + "JOIN Variant v ON p.id = v.product_id "
                + "GROUP BY c.name";
        try {
            connectDB();
            PreparedStatement ps = conn.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                data.put(rs.getString("category"), rs.getInt("total_stock"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return data;
    }

    // 3. Doanh thu theo tháng
    public Map<String, Double> getRevenueByMonth() {
        Map<String, Double> data = new LinkedHashMap<>();
        String sql = "SELECT FORMAT(order_date, 'yyyy-MM') AS month, SUM(total_amount) AS revenue "
                + "FROM Orders WHERE status = 1 "
                + "GROUP BY FORMAT(order_date, 'yyyy-MM') ORDER BY month";
        try {
            connectDB();
            PreparedStatement ps = conn.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                data.put(rs.getString("month"), rs.getDouble("revenue"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return data;
    }
    
}
