/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import java.sql.ResultSet;
import model.Customers;
import java.sql.PreparedStatement;
import java.util.*;

/**
 *
 * @author Acer - PC
 */
public class CustomersDAO extends DBconnection {

    public Customers getCustomer(String username, String password) {
        String query = "SELECT *FROM Customers "
                + "WHERE username = ? AND [password] = ?";

        connectDB();

        Object[] params = {username, password};

        try (ResultSet rs = execSelectQuery(query, params)) {
            if (rs.next()) {
                return new Customers(
                        rs.getInt("id"),
                        rs.getString("name"),
                        rs.getString("phone"),
                        rs.getString("email"),
                        rs.getString("address"),
                        rs.getString("username"),
                        rs.getString("password")
                );
            }
        } catch (Exception e) {
            System.out.println("Error retrieving customer: " + e.getMessage());
        }

        return null;
    }

    public int insertCustomer(String name, String email, String phone, String address, String username, String password) {
        String query = "INSERT INTO Customers (name, email, phone, address, username, password) VALUES (?, ?, ?, ?, ?, ?)";
        connectDB();
        try {
            PreparedStatement ps = conn.prepareStatement(query);
            ps.setString(1, name);
            ps.setString(2, email);
            ps.setString(3, phone);
            ps.setString(4, address);
            ps.setString(5, username);
            ps.setString(6, password);
            int rows = ps.executeUpdate(); //  dùng executeUpdate cho INSERT, UPDATE, DELETE
            return rows > 0 ? 1 : 0;
        } catch (Exception e) {
            e.printStackTrace(); // nên log lỗi để dễ debug
            return 0;
        }
    }

    public boolean isUsernameExist(String username) {
        String query = "SELECT * FROM Customers WHERE username = ?";
        connectDB();
        try {
            PreparedStatement ps = conn.prepareStatement(query);
            ps.setString(1, username);
            ResultSet rs = ps.executeQuery();
            return rs.next(); // nếu có dòng trả về => username tồn tại
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    public List<Customers> getAllCustomer() {
        List<Customers> list = new ArrayList<>();
        String query = " select id, name, email, phone, address from Customers;";
        connectDB();
        try (ResultSet rs = execSelectQuery(query)) {
            while (rs.next()) {
                Customers c = new Customers();
                c.setCustomer_id(rs.getInt("id"));
                c.setName(rs.getString("name"));
                c.setPhone(rs.getString("phone"));
                c.setEmail(rs.getString("email"));
                c.setAddress(rs.getString("address"));
                list.add(c);
            }
        } catch (Exception e) {
            return null;
        }
        return list;
    }

    public Customers getCustomerByid(int id) {
        Customers c = new Customers();
        String query = "SELECT id, name, email, phone, address, username, password FROM Customers WHERE id = ?";
        connectDB();

        try (ResultSet rs = execSelectQuery(query, new Object[]{id})) {
            if (rs.next()) { 
                c.setCustomer_id(rs.getInt("id"));
                c.setName(rs.getString("name"));
                c.setPhone(rs.getString("phone"));
                c.setEmail(rs.getString("email"));
                c.setAddress(rs.getString("address"));
                c.setUsername(rs.getString("username"));
                c.setPassword(rs.getString("password"));
                return c;
            } else {
                return null; 
            }
        } catch (Exception e) {
            return null;
        }
    }

    public int deleteCustomer(int id) {
        String query = "DELETE FROM Customers WHERE id = ?";
        connectDB(); // đảm bảo kết nối được mở

        try {
            PreparedStatement ps = conn.prepareStatement(query);
            ps.setInt(1, id);
            int rows = ps.executeUpdate(); // executeUpdate cho DELETE
            return rows > 0 ? 1 : 0;
        } catch (Exception e) {
            e.printStackTrace(); // log lỗi để dễ debug
            return 0;
        }
    }

    public int updateCustomer(int id, String name, String email, String phone, String address, String username, String password) {
        String query = "UPDATE Customers SET name = ?, email = ?, phone = ?, address = ?, username = ?, password = ? WHERE id = ?";
        connectDB();

        try {
            PreparedStatement ps = conn.prepareStatement(query);
            ps.setString(1, name);
            ps.setString(2, email);
            ps.setString(3, phone);
            ps.setString(4, address);
            ps.setString(5, username);
            ps.setString(6, password);
            ps.setInt(7, id);

            return ps.executeUpdate() > 0 ? 1 : 0;
        } catch (Exception e) {
            e.printStackTrace();
            return 0;
        }
    }

}
