/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import model.Staff;
import java.util.*;

/**
 *
 * @author Acer - PC
 */
public class StaffDAO extends DBconnection {

    public List<Staff> getAllStaff() {
        List<Staff> list = new ArrayList<>();
        connectDB();
        String query = "SELECT * FROM Staff;";
        try (ResultSet rs = execSelectQuery(query)) {
            while (rs.next()) {
                Staff s = new Staff();
                s.setStaff_id(rs.getInt("id"));
                s.setName(rs.getString("name"));
                s.setPhone(rs.getString("phone"));
                s.setEmail(rs.getString("email"));
                s.setUsername(rs.getString("username"));
                s.setPassword(rs.getString("password"));
                s.setStatus(rs.getString("Status"));
                list.add(s);
            }
        } catch (Exception e) {
            System.out.println("No result: " + e.getMessage());
        }
        return list;
    }

    public int insertStaff(String name, String phone, String email, String username, String password, String status) {
        String query = "INSERT INTO Staff (name, phone, email, username, password, status) VALUES (?, ?, ?, ?, ?, ?)";
        connectDB(); // mở kết nối trước khi thao tác
        try {
            PreparedStatement ps = conn.prepareStatement(query);
            ps.setString(1, name);
            ps.setString(2, phone);
            ps.setString(3, email);
            ps.setString(4, username);
            ps.setString(5, password);
            ps.setString(6, status); // truyền "Đang làm" mặc định nếu muốn
            int rows = ps.executeUpdate();
            return rows > 0 ? 1 : 0;
        } catch (Exception e) {
            e.printStackTrace(); // hiển thị lỗi trong console
            return 0;
        }
    }

    public Staff getStaffById(int id) {
        Staff s = new Staff();
        String query = "SELECT id, name, phone, email, username, password, status FROM Staff WHERE id = ?";
        connectDB();

        try (ResultSet rs = execSelectQuery(query, new Object[]{id})) {
            if (rs.next()) {
                s.setStaff_id(rs.getInt("id"));
                s.setName(rs.getString("name"));
                s.setPhone(rs.getString("phone"));
                s.setEmail(rs.getString("email"));
                s.setUsername(rs.getString("username"));
                s.setPassword(rs.getString("password"));
                s.setStatus(rs.getString("status")); // status kiểu String trong model bạn cung cấp
                return s;
            } else {
                return null;
            }
        } catch (Exception e) {
            System.out.println("Lỗi khi lấy staff theo ID: " + e.getMessage());
            return null;
        }
    }

    public boolean isUsernameExist(String username) {
        String query = "SELECT * FROM Staff WHERE username = ?";
        connectDB(); // đảm bảo mở kết nối trước
        try {
            PreparedStatement ps = conn.prepareStatement(query);
            ps.setString(1, username);
            ResultSet rs = ps.executeQuery();
            return rs.next(); // nếu có dữ liệu => username tồn tại
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    public int updateStaff(Staff staff) {
        String query = "UPDATE Staff SET name = ?, phone = ?, email = ?, username = ?, password = ?, Status = ? WHERE id = ?";
        connectDB();

        try {
            PreparedStatement ps = conn.prepareStatement(query);
            ps.setString(1, staff.getName());
            ps.setString(2, staff.getPhone());
            ps.setString(3, staff.getEmail());
            ps.setString(4, staff.getUsername());
            ps.setString(5, staff.getPassword());
            ps.setString(6, staff.getStatus());
            ps.setInt(7, staff.getStaff_id());

            return ps.executeUpdate() > 0 ? 1 : 0;
        } catch (Exception e) {
            e.printStackTrace();
            return 0;
        }
    }

    public int deleteStaff(int id) {
        String query = "DELETE FROM Staff WHERE id = ?";
        connectDB(); // đảm bảo đã kết nối với cơ sở dữ liệu

        try {
            PreparedStatement ps = conn.prepareStatement(query);
            ps.setInt(1, id);
            int rows = ps.executeUpdate(); // executeUpdate dùng cho DELETE
            return rows > 0 ? 1 : 0; // trả về 1 nếu thành công, ngược lại 0
        } catch (Exception e) {
            e.printStackTrace(); // in ra lỗi nếu có
            return 0;
        }
    }

    public int getIdStaffReaddy() {
        String sql = "SELECT TOP 1 id FROM Staff WHERE Status = 1";
        connectDB();
        try (PreparedStatement ps = conn.prepareStatement(sql)) {

            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return rs.getInt("id");
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return -1; // Trả về -1 nếu không tìm thấy staff phù hợp
    }

    public void setStaffStatus(int id) {
        String sql = "UPDATE Staff SET Status = CASE WHEN Status = 0 THEN 1 ELSE 0 END WHERE id = ?";
        connectDB(); 
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id); // truyền id nhân viên cần cập nhật
            int rows = ps.executeUpdate();
            if (rows > 0) {
                System.out.println("Đã cập nhật trạng thái nhân viên có ID = " + id + " thành 0.");
            } else {
                System.out.println("Không tìm thấy nhân viên có ID = " + id);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
