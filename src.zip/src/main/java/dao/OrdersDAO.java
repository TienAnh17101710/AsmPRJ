package dao;

import java.sql.*;
import model.Orders;
import java.util.*;

public class OrdersDAO extends DBconnection {

    // Thêm đơn hàng mới, trả về ID đơn hàng vừa tạo
    public int insertOrder(Orders order) {
        String sql = "INSERT INTO Orders (user_id, staff_id, order_date, total_amount, status) "
                + "OUTPUT INSERTED.id "
                + "VALUES (?, ?, ?, ?, ?)";

        try {
            connectDB();
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, order.getUserId());
            ps.setInt(2, order.getStaffId());
            ps.setDate(3, order.getOrderDate());
            ps.setLong(4, order.getTotalAmount());
            ps.setString(5, order.getStatus());

            ResultSet rs = ps.executeQuery(); 
            if (rs.next()) {
                return rs.getInt(1); // lấy ID vừa insert
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return 0;
    }

    public Orders getOrdersById(int id) {
        Orders s = new Orders();
        String query = "SELECT * FROM Orders WHERE id = ?";
        connectDB();

        try (ResultSet rs = execSelectQuery(query, new Object[]{id})) {
            if (rs.next()) {
                s.setId(rs.getInt("id"));
                s.setOrderDate(rs.getDate("order_date"));
                s.setStaffId(rs.getInt("staff_id"));
                s.setStatus(rs.getString("status"));
                s.setTotalAmount(rs.getInt("total_amount"));
                s.setUserId(rs.getInt("user_id"));
                return s;
            } else {
                return null;
            }
        } catch (Exception e) {
            System.out.println("Lỗi khi lấy orders theo ID: " + e.getMessage());
            return null;
        }
    }

    public List<Orders> getOrdersByCustomerId(int customerId) {
        List<Orders> list = new ArrayList<>();
        String sql = "SELECT * FROM Orders WHERE user_id = ?";
        connectDB();

        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, customerId);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                Orders order = new Orders();
                order.setId(rs.getInt("id"));
                order.setUserId(rs.getInt("user_id"));
                order.setStaffId(rs.getInt("staff_id"));
                order.setOrderDate(rs.getDate("order_date"));
                order.setTotalAmount(rs.getLong("total_amount"));
                order.setStatus(rs.getString("status"));
                list.add(order);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return list;
    }

    public List<Integer> getOrderIdsByCustomerId(int customerId) {
        List<Integer> orderIds = new ArrayList<>();
        String sql = "SELECT id FROM Orders WHERE user_id = ?";
        connectDB(); // đảm bảo conn đã được khởi tạo

        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, customerId);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                orderIds.add(rs.getInt("id"));
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return orderIds;
    }

    public void deleteOrdersByUserId(int userId) {
        String sql = "DELETE FROM Orders WHERE user_id = ?";
        connectDB(); // đảm bảo kết nối cơ sở dữ liệu

        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, userId);
            ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public int deleteOrders(int id) {
        String deleteDetailsSQL = "Delete from Order_details where order_id = ?";
        String deleteOrdersSQL = "Delete from Orders where id = ?";
        connectDB();
        try {
            conn.setAutoCommit(false);
            try (PreparedStatement ps1 = conn.prepareStatement(deleteDetailsSQL); PreparedStatement ps2 = conn.prepareStatement(deleteOrdersSQL)) {
                ps1.setInt(1, id);
                ps1.executeUpdate();

                ps2.setInt(1, id);
                int affected = ps2.executeUpdate();
                conn.commit();
                return affected;
            } catch (Exception e) {
                conn.rollback();
                e.printStackTrace();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return 0;
    }

    public List<Orders> getAllOrders() {
        List<Orders> list = new ArrayList<>();
        connectDB();
        String query = "SELECT * FROM Orders;";
        try (ResultSet rs = execSelectQuery(query)) {
            while (rs.next()) {
                Orders s = new Orders();
                s.setId(rs.getInt("id"));
                s.setUserId(rs.getInt("user_id"));
                s.setStaffId(rs.getInt("staff_id"));
                s.setOrderDate(rs.getDate("order_date"));
                s.setTotalAmount(rs.getInt("total_amount"));
                s.setStatus(rs.getString("status"));
                list.add(s);
            }
        } catch (Exception e) {
            System.out.println("No result: " + e.getMessage());
        }
        return list;
    }

    public int setStatus(int id) {
        String query = " update Orders set status=1 where id=?";
        try {
            connectDB();
            PreparedStatement ps = conn.prepareStatement(query);
            ps.setInt(1, id);
            int rowsUpdated = ps.executeUpdate();
            return rowsUpdated;
        } catch (Exception e) {
        }
        return 0;
    }
}
