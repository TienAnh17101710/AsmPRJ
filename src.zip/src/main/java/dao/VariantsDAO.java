package dao;

import java.sql.*;
import java.util.*;
import model.*;

public class VariantsDAO extends DBconnection {

    public List<Variants> getAllVariants() {
        List<Variants> list = new ArrayList<>();
        String sql = "SELECT * FROM Variant";
        try {
            connectDB();
            PreparedStatement ps = conn.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new Variants(
                        rs.getInt("id"),
                        rs.getString("size"),
                        rs.getString("ice"),
                        rs.getString("sugar"),
                        rs.getDouble("price"),
                        rs.getInt("stock_quantity"),
                        rs.getInt("product_id")
                ));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    public Variants getVariantByOptions(int productId, String size, String sugar, String ice) {
        String sql = "SELECT * FROM Variant WHERE product_id = ? AND size = ? AND sugar = ? AND ice = ?";
        try {
            connectDB();
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, productId);
            ps.setString(2, size);
            ps.setString(3, sugar);
            ps.setString(4, ice);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return new Variants(
                        rs.getInt("id"),
                        rs.getString("size"),
                        rs.getString("ice"),
                        rs.getString("sugar"),
                        rs.getDouble("price"),
                        rs.getInt("stock_quantity"),
                        rs.getInt("product_id")
                );
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public Variants getVariantByID(int id) {
        String query = "select*from Variant where id=?";
        try {
            connectDB();
            PreparedStatement ps = conn.prepareStatement(query);
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return new Variants(
                        rs.getInt("id"),
                        rs.getString("size"),
                        rs.getString("ice"),
                        rs.getString("sugar"),
                        rs.getDouble("price"),
                        rs.getInt("stock_quantity"),
                        rs.getInt("product_id")
                );
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }
    
    public void updateStockQuantity(int Id, int newStock) {
        String sql = "UPDATE Variant SET stock_quantity = ? WHERE id = ?";
        try (Connection conn = connectDB(); 
                PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, newStock);
            ps.setInt(2, Id);
            ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
