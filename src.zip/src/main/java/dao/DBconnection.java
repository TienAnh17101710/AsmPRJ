package dao;

import java.sql.Connection;
import java.sql.DriverManager;

/**
 *
 * @author Duong Quy Nhan
 */

import java.sql.*;

public class DBconnection {
    public static String driverName = "com.microsoft.sqlserver.jdbc.SQLServerDriver";
    public static String dbURL = "jdbc:sqlserver://localhost:1433;databaseName=coffee_shop;encrypt=true;trustServerCertificate=true";
    public static String userDB = "sa";
    public static String passDB = "123456";
    Connection conn = null;
    
    public Connection connectDB() {
        try {
            Class.forName(driverName);
            conn = DriverManager.getConnection(dbURL, userDB, passDB);
            System.out.println("ket noi thanh cong");
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("khong thanh cong");
        }
        return conn;
    }
        // Phương thức cho các lệnh SELECT (có params)
    public ResultSet execSelectQuery(String query, Object[] params) throws SQLException {
        PreparedStatement preparedStatement = conn.prepareStatement(query);
        if (params != null) {
            for (int i = 0; i < params.length; i++) {
                preparedStatement.setObject(i + 1, params[i]);
            }
        }
        return preparedStatement.executeQuery();
    }

    // Phương thức cho các lệnh SELECT (không có params)
    public ResultSet execSelectQuery(String query) throws SQLException {
        return this.execSelectQuery(query, null);
    }

    // Phương thức cho các lệnh INSERT, UPDATE, DELETE
    public int execQuery(String query, Object[] params) throws SQLException {
        PreparedStatement preparedStatement = conn.prepareStatement(query);
        if (params != null) {
            for (int i = 0; i < params.length; i++) {
                preparedStatement.setObject(i + 1, params[i]);
            }
        }
        return preparedStatement.executeUpdate();
    }
        public static void main(String[] args) {
    DBconnection luom= new DBconnection();
    System.out.println(luom.connectDB());
    }
}