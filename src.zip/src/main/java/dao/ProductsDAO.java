package dao;

import java.sql.*;
import java.util.*;
import model.*;

public class ProductsDAO extends DBconnection {

    public List<Products> getAllProducts() {
        List<Products> list = new ArrayList<>();
        String sql = "SELECT * FROM Products";
        try {
            connectDB();
            PreparedStatement ps = conn.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new Products(
                        rs.getInt("id"),
                        rs.getString("name"),
                        rs.getInt("variant_id"),
                        rs.getInt("category_id"),
                        rs.getString("img")
                ));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    public Products getProductById(int id) {
        String sql = "SELECT * FROM Products WHERE id = ?";
        try {
            connectDB();
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return new Products(
                        rs.getInt("id"),
                        rs.getString("name"),
                        rs.getInt("variant_id"),
                        rs.getInt("category_id"),
                        rs.getString("img")
                );
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public int updateProduct(Products p) {
        connectDB();
        String query = "UPDATE Products SET name = ?, category_id = ?, img = ? WHERE id = ?";

        try {
            PreparedStatement ps = conn.prepareStatement(query);
            ps.setString(1, p.getName());
            ps.setInt(2, p.getCategoryId());
            ps.setString(3, p.getImg());
            ps.setInt(4, p.getId());
            return ps.executeUpdate();
        } catch (Exception e) {
            System.out.println("Error updateProduct: " + e.getMessage());
            return 0;
        }

    }

    public int deleteProduct(int id) {
        connectDB();
        String sql = "Delete from products where id = ?";
        try {
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, id);
            return ps.executeUpdate();
        } catch (Exception e) {
            System.out.println("Error delete Product" + e.getMessage());
            return 0;
        }
    }

    public int insertProduct(String name, int category_id, String img) {
        connectDB();
        String sql = "INSERT INTO Products(name, category_id, img) VALUES (?, ?, ?)";
        try {
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, name);
            ps.setInt(2, category_id);
            ps.setString(3, img);
            return ps.executeUpdate();
        } catch (Exception e) {
            System.out.println("Error insertProduct: " + e.getMessage());
            return 0;
        }
    }

    public Products getNameByID(int id) {
        String query = "  select [name] from Products where id=?";
        try {
            connectDB();
            PreparedStatement ps = conn.prepareStatement(query);
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return new Products(rs.getString("name"));
            }
        } catch (Exception e) {
            System.out.println("Error insertProduct: " + e.getMessage());

        }
        return null;
    }
        public List<Products> searchProductsByName(String keyword) {
        List<Products> list = new ArrayList<>();
        String sql = "SELECT * FROM Products WHERE name LIKE ?";
        try {
            connectDB();
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, "%" + keyword + "%");
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new Products(
                        rs.getInt("id"),
                        rs.getString("name"),
                        rs.getInt("variant_id"),
                        rs.getInt("category_id"),
                        rs.getString("img")
                ));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }
}
