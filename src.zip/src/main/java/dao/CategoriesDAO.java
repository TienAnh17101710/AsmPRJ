/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import model.Categories;
import java.util.*;
import java.sql.*;

/**
 *
 * @author Acer - PC
 */
public class CategoriesDAO extends DBconnection {

    public List<Categories> getAllCategories() {
        List<Categories> list = new ArrayList<>();
        connectDB();
        String query = "SELECT * FROM Categories";
        try (ResultSet rs = execSelectQuery(query)) {
            while (rs.next()) {
                Categories p = new Categories();
                p.setId(rs.getInt("id"));
                p.setName(rs.getString("name"));
                p.setDescription(rs.getString("description"));
                p.setStatus(rs.getInt("status"));
                list.add(p);
            }
        } catch (Exception e) {
            System.out.println("No result: " + e.getMessage());
        }
        return list;
    }

    public Categories getCategoriesByID(int id) {
        Categories s = new Categories();
        String query = "SELECT * FROM Categories WHERE id = ?";
        connectDB();

        try (ResultSet rs = execSelectQuery(query, new Object[]{id})) {
            if (rs.next()) {
                s.setId(rs.getInt("id"));
                s.setName(rs.getString("name"));
                s.setDescription(rs.getString("description"));
                s.setStatus(rs.getInt("status"));
                return s;
            } else {
                return null;
            }
        } catch (Exception e) {
            System.out.println("Lỗi khi lấy categories theo ID: " + e.getMessage());
            return null;
        }
    }

    public int updateCategories(Categories p) {
        connectDB();
        String query = "UPDATE Categories SET name = ?,description = ? WHERE id = ?";

        try {
            PreparedStatement ps = conn.prepareStatement(query);
            ps.setString(1, p.getName());
            ps.setString(2, p.getDescription());
            ps.setInt(3, p.getId());
            return ps.executeUpdate();
        } catch (Exception e) {
            System.out.println("Error updateCategories: " + e.getMessage());
            return 0;
        }

    }

    public int insertCategories(String name, String description) {
        connectDB();
        String sql = "INSERT INTO Categories(name, description) VALUES (?, ?)";
        try {
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, name);
            ps.setString(2, description);
            return ps.executeUpdate();
        } catch (Exception e) {
            System.out.println("Error insert Categories: " + e.getMessage());
            return 0;
        }
    }

    public int deleteCategories(int id) {
        connectDB();
        String deleteProductsSQL = "DELETE FROM Products WHERE category_id = ?";
        String deleteCategorySQL = "DELETE FROM Categories WHERE id = ?";

        try {
            conn.setAutoCommit(false); // Bắt đầu transaction

            try (PreparedStatement ps1 = conn.prepareStatement(deleteProductsSQL); PreparedStatement ps2 = conn.prepareStatement(deleteCategorySQL)) {

                // Xóa các sản phẩm thuộc danh mục
                ps1.setInt(1, id);
                ps1.executeUpdate();

                // Xóa danh mục
                ps2.setInt(1, id);
                int affected = ps2.executeUpdate();

                conn.commit(); // Xác nhận transaction
                return affected;
            } catch (Exception ex) {
                conn.rollback(); // Quay lui nếu có lỗi
                ex.printStackTrace();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return 0;
    }

    public boolean isCategoryNameExist(String name) {
        connectDB();
        String sql = "SELECT COUNT(*) FROM Categories WHERE name = ?";
        try (
                PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, name);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                int count = rs.getInt(1);
                return count > 0;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    public int toggleCategoryStatus(int id) {
        connectDB();
        String query = "UPDATE Categories SET status = CASE WHEN status = 1 THEN 0 ELSE 1 END WHERE id = ?";

        try {
            PreparedStatement ps = conn.prepareStatement(query);
            ps.setInt(1, id);
            return ps.executeUpdate(); // Trả về số dòng bị ảnh hưởng (1 nếu thành công)
        } catch (Exception e) {
            System.out.println("Error toggleCategoryStatus: " + e.getMessage());
            return 0;
        }
    }

    public int toggleCategoryStatusIfNoActiveOrders(int categoryId) {
        connectDB();

        String checkActiveOrders
                = "SELECT COUNT(*) FROM Orders o "
                + "JOIN Order_Details od ON o.id = od.order_id "
                + "JOIN Variant v ON od.variant_id = v.id "
                + "JOIN Products p ON v.product_id = p.id "
                + "WHERE o.status = 0 AND p.category_id = ?";

        String toggleStatus
                = "UPDATE Categories "
                + "SET status = CASE WHEN status = 1 THEN 0 ELSE 1 END "
                + "WHERE id = ?";

        try {
            // 1. Kiểm tra xem có đơn hàng nào đang xử lý liên quan không
            PreparedStatement psCheck = conn.prepareStatement(checkActiveOrders);
            psCheck.setInt(1, categoryId);
            ResultSet rs = psCheck.executeQuery();

            if (rs.next() && rs.getInt(1) == 0) {
                // 2. Không có đơn đang xử lý → cho phép toggle
                PreparedStatement psToggle = conn.prepareStatement(toggleStatus);
                psToggle.setInt(1, categoryId);
                return psToggle.executeUpdate();
            } else {
                System.out.println("Không thể tắt danh mục vì còn đơn hàng đang xử lý.");
                return 0;
            }
        } catch (Exception e) {
            System.out.println("Error toggleCategoryStatusIfNoActiveOrders: " + e.getMessage());
            return 0;
        }
    }

}
