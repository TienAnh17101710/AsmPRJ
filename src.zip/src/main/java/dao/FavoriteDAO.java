package dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*;
import model.*;

public class FavoriteDAO extends DBconnection {

    public void addToFavorite(int customerId, int productId) {
        connectDB();
        String sql = "INSERT INTO Favorite (customer_id, product_id) VALUES (?, ?)";
        PreparedStatement ps = null;

        try {
            ps = conn.prepareStatement(sql);
            ps.setInt(1, customerId);
            ps.setInt(2, productId);
            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                if (ps != null) ps.close();
                if (conn != null) conn.close();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
    }

    public void removeFromFavorite(int customerId, int productId) {
        connectDB();
        String sql = "DELETE FROM Favorite WHERE customer_id = ? AND product_id = ?";
        PreparedStatement ps = null;

        try {
            ps = conn.prepareStatement(sql);
            ps.setInt(1, customerId);
            ps.setInt(2, productId);
            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                if (ps != null) ps.close();
                if (conn != null) conn.close();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
    }

    public List<Products> getFavoriteProducts(int customerId) {
        connectDB();
        List<Products> list = new ArrayList<>();
        String sql = "SELECT * FROM Products p JOIN Favorite f ON p.id = f.product_id WHERE f.customer_id = ?";
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            ps = conn.prepareStatement(sql);
            ps.setInt(1, customerId);
            rs = ps.executeQuery();
            while (rs.next()) {
                Products p = new Products(
                        rs.getInt("id"),
                        rs.getString("name"),
                        rs.getInt("variant_id"),
                        rs.getInt("category_id"),
                        rs.getString("img")
                );
                list.add(p);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) rs.close();
                if (ps != null) ps.close();
                if (conn != null) conn.close();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }

        return list;
    }

    public boolean isFavorite(int customerId, int productId) {
        connectDB();
        String sql = "SELECT * FROM Favorite WHERE customer_id = ? AND product_id = ?";
        PreparedStatement ps = null;
        ResultSet rs = null;
        boolean exists = false;

        try {
            ps = conn.prepareStatement(sql);
            ps.setInt(1, customerId);
            ps.setInt(2, productId);
            rs = ps.executeQuery();
            exists = rs.next();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) rs.close();
                if (ps != null) ps.close();
                if (conn != null) conn.close();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }

        return exists;
    }
}
