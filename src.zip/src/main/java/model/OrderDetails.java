
package model;

public class OrderDetails {
    private int id;
    private int orderId;
    private int variantId;
    private int quantity;

    // Constructors, Getters, Setters
    public OrderDetails() {}

    public OrderDetails(int id, int orderId, int variantId, int quantity) {
        this.id = id;
        this.orderId = orderId;
        this.variantId = variantId;
        this.quantity = quantity;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getOrderId() {
        return orderId;
    }

    public void setOrderId(int orderId) {
        this.orderId = orderId;
    }

    public int getVariantId() {
        return variantId;
    }

    public void setVariantId(int variantId) {
        this.variantId = variantId;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }
}


