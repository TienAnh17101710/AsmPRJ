/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author Acer - PC
 */
import java.util.Date;

public class Voucher {

    private int id;
    private String code;
    private double discount;
    private String type; // "percent" hoặc "cash"
    private double minOrder;
    private Date expiredDate;
    private int status;

    public Voucher() {
    }

    public Voucher(int id, String code, double discount, String type, double minOrder, Date expiredDate, int status) {
        this.id = id;
        this.code = code;
        this.discount = discount;
        this.type = type;
        this.minOrder = minOrder;
        this.expiredDate = expiredDate;
        this.status = status;
    }

    public boolean isValid() {
        return expiredDate != null && expiredDate.after(new java.util.Date()) && status == 1;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public double getDiscount() {
        return discount;
    }

    public void setDiscount(double discount) {
        this.discount = discount;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public double getMinOrder() {
        return minOrder;
    }

    public void setMinOrder(double minOrder) {
        this.minOrder = minOrder;
    }

    public Date getExpiredDate() {
        return expiredDate;
    }

    public void setExpiredDate(Date expiredDate) {
        this.expiredDate = expiredDate;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

}
