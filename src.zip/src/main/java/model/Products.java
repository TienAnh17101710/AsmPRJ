
package model;

public class Products {
    private int id;
    private String name;
    private int variantId;
    private int categoryId;
    private String img;

    // Constructors, Getters, Setters

    public Products() {
    }

    public Products(String name) {
        this.name = name;
    }
    
    public Products(int id, String name, int variantId, int categoryId, String img) {
        this.id = id;
        this.name = name;
        this.variantId = variantId;
        this.categoryId = categoryId;
        this.img = img;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getVariantId() {
        return variantId;
    }

    public void setVariantId(int variantId) {
        this.variantId = variantId;
    }

    public int getCategoryId() {
        return categoryId;
    }

    public void setCategoryId(int categoryId) {
        this.categoryId = categoryId;
    }

    public String getImg() {
        return img;
    }

    public void setImg(String img) {
        this.img = img;
    }

}


