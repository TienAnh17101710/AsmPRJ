
package model;

public class Variants {
    private int id;
    private String size;
    private String ice;
    private String sugar;
    private double price;
    private int stockQuantity;
    private int productId;

    // Constructors, Getters, Setters
    public Variants() {}

    public Variants(int id, String size, String ice, String sugar, double price, int stockQuantity, int productId) {
        this.id = id;
        this.size = size;
        this.ice = ice;
        this.sugar = sugar;
        this.price = price;
        this.stockQuantity = stockQuantity;
        this.productId = productId;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getSize() {
        return size;
    }

    public void setSize(String size) {
        this.size = size;
    }

    public String getIce() {
        return ice;
    }

    public void setIce(String ice) {
        this.ice = ice;
    }

    public String getSugar() {
        return sugar;
    }

    public void setSugar(String sugar) {
        this.sugar = sugar;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public int getStockQuantity() {
        return stockQuantity;
    }

    public void setStockQuantity(int stockQuantity) {
        this.stockQuantity = stockQuantity;
    }

    public int getProductId() {
        return productId;
    }

    public void setProductId(int productId) {
        this.productId = productId;
    }
}


