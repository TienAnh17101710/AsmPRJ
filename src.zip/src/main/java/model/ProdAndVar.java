
package model;

public class ProdAndVar {
    private Products products;
    private Variants variants;
    private int quantity;
    
    public ProdAndVar() {
    }

    public ProdAndVar(Products products, Variants variants) {
        this.products = products;
        this.variants = variants;
    }
    
    public ProdAndVar(Products products, Variants variants, int quantity) {
        this.products = products;
        this.variants = variants;
        this.quantity = quantity;
    }

    public Products getProducts() {
        return products;
    }

    public void setProducts(Products products) {
        this.products = products;
    }

    public Variants getVariants() {
        return variants;
    }

    public void setVariants(Variants variants) {
        this.variants = variants;
    }   

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }
    
    
}
