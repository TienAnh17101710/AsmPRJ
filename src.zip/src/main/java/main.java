/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Acer - PC
 */
import model.*;
import dao.*;
import java.util.*;
import java.text.SimpleDateFormat;

public class main {

      public static void main(String[] args) {
        VoucherDAO dao = new VoucherDAO();

        Voucher v = new Voucher();
        v.setCode("TEST50");
        v.setType("percent");
        v.setDiscount(50.0);
       v.setExpiredDate(java.sql.Date.valueOf("2025-12-31"));
        v.setStatus(1);

        boolean success = dao.insertVoucher(v);
        System.out.println(success ? "✅ Insert thành công" : "❌ Insert thất bại");
    }
}
